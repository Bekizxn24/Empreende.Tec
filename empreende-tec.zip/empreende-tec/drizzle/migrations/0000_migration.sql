
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null default '',
  tipo text not null default 'comprador' check (tipo in ('comprador','vendedor')),
  loja text not null default '',
  whatsapp text not null default '',
  pix_tipo text not null default '',
  pix_chave text not null default '',
  formas_pagamento text[] not null default '{}',
  created_at timestamptz not null default now()
);
grant select (id, nome, tipo, loja) on public.profiles to anon;
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "perfis visiveis" on public.profiles for select to anon, authenticated using (true);
create policy "edita o proprio" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "cria o proprio" on public.profiles for insert to authenticated with check (auth.uid() = id);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
begin
  insert into public.profiles(id, nome, tipo, loja, whatsapp, pix_tipo, pix_chave, formas_pagamento)
  values (
    new.id,
    coalesce(nullif(m->>'nome',''), m->>'full_name', m->>'name', split_part(new.email,'@',1)),
    case when m->>'tipo' = 'vendedor' then 'vendedor' else 'comprador' end,
    coalesce(m->>'loja',''), coalesce(m->>'whatsapp',''),
    coalesce(m->>'pix_tipo',''), coalesce(m->>'pix_chave',''),
    case when jsonb_typeof(m->'formas_pagamento') = 'array'
      then array(select jsonb_array_elements_text(m->'formas_pagamento')) else '{}'::text[] end
  );
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create table public.categorias (
  id serial primary key, nome text not null unique, icone text not null default ''
);
grant select on public.categorias to anon, authenticated;
grant all on public.categorias to service_role;
alter table public.categorias enable row level security;
create policy "categorias publicas" on public.categorias for select to anon, authenticated using (true);
insert into public.categorias(nome, icone) values
 ('Doces','🍰'),('Bebidas','🥤'),('Lanches','🥪'),('Artesanato','🎨'),
 ('Roupas','👕'),('Materiais','📦'),('Serviços','🛠️'),('Outros','🛍️');

create table public.produtos (
  id uuid primary key default gen_random_uuid(),
  vendedor_id uuid not null references public.profiles(id) on delete cascade,
  categoria_id int not null references public.categorias(id),
  tipo text not null default 'Produto' check (tipo in ('Produto','Serviço')),
  nome text not null,
  descricao text not null default '',
  preco numeric(10,2) not null check (preco >= 0),
  quantidade int not null default 1 check (quantidade >= 0),
  local_entrega text not null default '',
  imagem_url text not null default '',
  views int not null default 0,
  created_at timestamptz not null default now()
);
grant select on public.produtos to anon;
grant select, insert, update, delete on public.produtos to authenticated;
grant all on public.produtos to service_role;
alter table public.produtos enable row level security;
create or replace function public.is_vendedor(_uid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = _uid and tipo = 'vendedor')
$$;
create policy "produtos publicos" on public.produtos for select to anon, authenticated using (true);
create policy "vendedor cria" on public.produtos for insert to authenticated
  with check (auth.uid() = vendedor_id and public.is_vendedor(auth.uid()));
create policy "vendedor edita" on public.produtos for update to authenticated
  using (auth.uid() = vendedor_id) with check (auth.uid() = vendedor_id);
create policy "vendedor exclui" on public.produtos for delete to authenticated using (auth.uid() = vendedor_id);

create or replace function public.contar_visita(_id uuid) returns void
language sql security definer set search_path = public as $$
  update public.produtos set views = views + 1 where id = _id
$$;
grant execute on function public.contar_visita(uuid) to anon, authenticated;

create table public.pedidos (
  id uuid primary key default gen_random_uuid(),
  produto_id uuid not null references public.produtos(id) on delete cascade,
  comprador_id uuid not null references public.profiles(id) on delete cascade,
  vendedor_id uuid not null references public.profiles(id) on delete cascade,
  quantidade int not null default 1 check (quantidade > 0),
  forma_pagamento text not null,
  total numeric(10,2) not null default 0,
  mensagem text not null default '',
  created_at timestamptz not null default now()
);
grant select, insert on public.pedidos to authenticated;
grant all on public.pedidos to service_role;
alter table public.pedidos enable row level security;
create policy "ver os seus pedidos" on public.pedidos for select to authenticated
  using (auth.uid() = comprador_id or auth.uid() = vendedor_id);
create policy "comprador cria pedido" on public.pedidos for insert to authenticated
  with check (auth.uid() = comprador_id and exists(select 1 from public.produtos p where p.id = produto_id and p.vendedor_id = pedidos.vendedor_id));

create policy "upload na propria pasta" on storage.objects for insert to authenticated
  with check (bucket_id = 'produtos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "remove da propria pasta" on storage.objects for delete to authenticated
  using (bucket_id = 'produtos' and (storage.foldername(name))[1] = auth.uid()::text);
