# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Banco de dados

O backend (autenticação, banco e armazenamento de imagens) roda no Lovable Cloud.
Para apontar o projeto para um backend seu, ajuste `.env` com a URL e a chave
publicável do seu projeto e depois aplique as migrations que estão em
`drizzle/migrations/`, na ordem (`0000_migration.sql` cria as tabelas
`profiles`, `categorias`, `produtos` e `pedidos`, as regras de privacidade e o
gatilho que cria o perfil no cadastro; `0001_migration.sql` libera a leitura
das imagens do bucket `produtos`).

## Testes

```sh
bunx vitest run
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
