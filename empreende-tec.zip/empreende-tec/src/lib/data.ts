import { supabase } from "@/integrations/supabase/client";

export type ProdutoItem = {
  id: string;
  nome: string;
  descricao: string;
  tipo: string;
  preco: number;
  quantidade: number;
  local_entrega: string;
  imagem_url: string;
  views: number;
  created_at: string;
  vendedor_id: string;
  categoria_id: number;
  categoria: { nome: string; icone: string } | null;
  vendedor: { nome: string; loja: string } | null;
  imagem: string | null;
};

const SEL = "id,nome,descricao,tipo,preco,quantidade,local_entrega,imagem_url,views,created_at,vendedor_id,categoria_id,categoria:categorias(nome,icone),vendedor:profiles!produtos_vendedor_id_fkey(nome,loja)";

async function comImagens(rows: Omit<ProdutoItem, "imagem">[]): Promise<ProdutoItem[]> {
  const paths = rows.map((r) => r.imagem_url).filter(Boolean);
  const urls = new Map<string, string>();
  if (paths.length) {
    const { data } = await supabase.storage.from("produtos").createSignedUrls(paths, 60 * 60 * 24);
    data?.forEach((d) => d.path && d.signedUrl && urls.set(d.path, d.signedUrl));
  }
  return rows.map((r) => ({ ...r, imagem: urls.get(r.imagem_url) ?? null }));
}

export async function listarProdutos(f: { q?: string | undefined; tipo?: string | undefined; categoria?: string | undefined; vendedor?: string | undefined } = {}) {
  let query = supabase.from("produtos").select(SEL).order("created_at", { ascending: false });
  if (f.q) query = query.or(`nome.ilike.%${f.q.replace(/[,%()]/g, " ")}%,descricao.ilike.%${f.q.replace(/[,%()]/g, " ")}%`);
  if (f.tipo) query = query.eq("tipo", f.tipo);
  if (f.categoria) query = query.eq("categoria_id", Number(f.categoria));
  if (f.vendedor) query = query.eq("vendedor_id", f.vendedor);
  const { data, error } = await query;
  if (error) throw error;
  return comImagens((data ?? []) as unknown as Omit<ProdutoItem, "imagem">[]);
}

export async function buscarProduto(id: string) {
  const { data, error } = await supabase.from("produtos").select(SEL).eq("id", id).maybeSingle();
  if (error) throw error;
  if (!data) return null;
  return (await comImagens([data as unknown as Omit<ProdutoItem, "imagem">]))[0];
}

export async function listarCategorias() {
  const { data } = await supabase.from("categorias").select("*").order("id");
  return data ?? [];
}

export async function enviarImagem(uid: string, file: File) {
  const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
  const path = `${uid}/${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from("produtos").upload(path, file, { contentType: file.type });
  if (error) throw error;
  return path;
}
