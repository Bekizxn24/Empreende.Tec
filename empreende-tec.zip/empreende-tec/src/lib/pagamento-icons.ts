import { ArrowLeftRight, Banknote, CreditCard, QrCode, type LucideIcon } from "lucide-react";

/** Ícone de cada forma de pagamento aceita pelos vendedores. */
export const FORMAS_ICONE: Record<string, LucideIcon> = {
  Pix: QrCode,
  Dinheiro: Banknote,
  "Cartão de débito": CreditCard,
  "Cartão de crédito": CreditCard,
  "Transferência bancária": ArrowLeftRight,
};
