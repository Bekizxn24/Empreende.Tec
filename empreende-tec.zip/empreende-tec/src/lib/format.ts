export const FORMAS_PAGAMENTO = [
  "Pix",
  "Dinheiro",
  "Cartão de débito",
  "Cartão de crédito",
  "Transferência bancária",
] as const;

export const TIPOS_PIX = ["CPF", "CNPJ", "E-mail", "Telefone", "Chave aleatória"] as const;

export function brl(v: number | string) {
  return Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function digitos(v: string | null | undefined) {
  return (v ?? "").replace(/\D/g, "");
}

/** Normaliza um WhatsApp brasileiro para o formato internacional usado pelo wa.me. */
export function whatsappIntl(v: string) {
  const d = digitos(v);
  if (!d) return "";
  return d.length <= 11 ? `55${d}` : d;
}

export function linkWhatsapp(numero: string, mensagem: string) {
  return `https://wa.me/${whatsappIntl(numero)}?text=${encodeURIComponent(mensagem)}`;
}

export function mensagemPedido(p: {
  vendedor: string;
  produto: string;
  quantidade: number;
  total: number;
  forma: string;
  comprador: string;
}) {
  const linhas = [
    `Olá, ${p.vendedor}! Sou ${p.comprador} e fiz um pedido pelo Empreende Tec:`,
    `• ${p.quantidade}x ${p.produto}`,
    `• Total: ${brl(p.total)}`,
    `• Pagamento: ${p.forma}`,
  ];
  if (p.forma === "Pix") linhas.push("", "Segue o comprovante do Pix 👇");
  else linhas.push("", "Podemos combinar o pagamento e a entrega?");
  return linhas.join("\n");
}
