import { describe, expect, it } from "vitest";
import { linkWhatsapp, mensagemPedido, whatsappIntl } from "./format";

describe("WhatsApp do vendedor", () => {
  it("adiciona o código do Brasil a números locais", () => {
    expect(whatsappIntl("(71) 99999-1234")).toBe("5571999991234");
  });
  it("mantém números já internacionais", () => {
    expect(whatsappIntl("+55 71 99999-1234")).toBe("5571999991234");
  });
  it("pede o comprovante quando o pagamento é Pix", () => {
    const msg = mensagemPedido({ vendedor: "Ana", produto: "Brigadeiro", quantidade: 2, total: 6, forma: "Pix", comprador: "Luis" });
    expect(msg).toContain("comprovante");
    expect(linkWhatsapp("71999991234", msg)).toMatch(/^https:\/\/wa\.me\/5571999991234\?text=/);
  });
});
