import { Link, useNavigate } from "@tanstack/react-router";
import { LogOut, Menu, Store, User } from "lucide-react";
import { useState } from "react";
import logo from "@/assets/logo.png";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

const links = [
  { to: "/", label: "Início" },
  { to: "/produtos", label: "Vitrine" },
  { to: "/sobre", label: "Sobre" },
] as const;

export function SiteHeader() {
  const { session, perfil } = useAuth();
  const navigate = useNavigate();
  const [aberto, setAberto] = useState(false);

  async function sair() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4">
        <Link to="/" className="flex items-center gap-2">
          <img src={logo} alt="Empreende Tec" className="h-11 w-auto" />
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              className="rounded-full px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground data-[status=active]:bg-secondary data-[status=active]:text-foreground"
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto hidden items-center gap-2 md:flex">
          {session ? (
            <>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/painel"><Store /> Painel</Link>
              </Button>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/perfil"><User /> {perfil?.nome?.split(" ")[0] || "Perfil"}</Link>
              </Button>
              <Button variant="outline" size="sm" onClick={sair}><LogOut /> Sair</Button>
            </>
          ) : (
            <>
              <Button variant="ghost" asChild><Link to="/auth">Entrar</Link></Button>
              <Button asChild><Link to="/auth" search={{ modo: "cadastro" }}>Criar conta</Link></Button>
            </>
          )}
        </div>
        <Button variant="ghost" size="icon" className="ml-auto md:hidden" onClick={() => setAberto(!aberto)} aria-label="Menu">
          <Menu />
        </Button>
      </div>
      {aberto && (
        <div className="border-t border-border bg-background px-4 py-3 md:hidden" onClick={() => setAberto(false)}>
          <div className="flex flex-col gap-1">
            {links.map((l) => (
              <Link key={l.to} to={l.to} className="rounded-lg px-3 py-2 font-medium">{l.label}</Link>
            ))}
            {session ? (
              <>
                <Link to="/painel" className="rounded-lg px-3 py-2 font-medium">Painel</Link>
                <Link to="/perfil" className="rounded-lg px-3 py-2 font-medium">Meu perfil</Link>
                <button onClick={sair} className="rounded-lg px-3 py-2 text-left font-medium text-wine">Sair</button>
              </>
            ) : (
              <>
                <Link to="/auth" className="rounded-lg px-3 py-2 font-medium">Entrar</Link>
                <Link to="/auth" search={{ modo: "cadastro" }} className="rounded-lg px-3 py-2 font-medium text-primary-deep">Criar conta</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
