import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-semibold cursor-pointer select-none transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-gradient-warm text-primary-foreground shadow-glow btn-sheen hover:-translate-y-0.5 hover:brightness-[1.06] active:translate-y-0 active:brightness-100",
        destructive:
          "bg-destructive text-destructive-foreground shadow-soft hover:-translate-y-0.5 hover:brightness-110 active:translate-y-0",
        outline:
          "border border-border bg-card/70 text-foreground shadow-soft hover:-translate-y-0.5 hover:border-primary/50 hover:bg-secondary hover:text-primary-deep hover:shadow-lift active:translate-y-0",
        secondary:
          "bg-secondary text-secondary-foreground shadow-soft hover:-translate-y-0.5 hover:bg-accent hover:shadow-lift active:translate-y-0",
        ghost: "text-muted-foreground hover:bg-secondary hover:text-foreground",
        link: "text-primary-deep underline-offset-4 hover:underline",
        hero: "bg-gradient-warm text-primary-foreground shadow-lift btn-sheen ring-1 ring-primary-foreground/25 hover:-translate-y-1 hover:brightness-[1.07] active:translate-y-0",
        ink: "bg-gradient-ink text-ink-foreground shadow-lift btn-sheen ring-1 ring-ink-foreground/15 hover:-translate-y-0.5 active:translate-y-0",
        whatsapp:
          "bg-gradient-success text-success-foreground shadow-glow-success btn-sheen hover:-translate-y-0.5 hover:brightness-[1.06] active:translate-y-0",
      },
      size: {
        default: "h-10 px-5 py-2",
        sm: "h-8 px-3.5 text-xs",
        lg: "h-12 px-7 text-base",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
