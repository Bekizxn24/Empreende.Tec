import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FORMAS_PAGAMENTO, TIPOS_PIX } from "@/lib/format";
import { FORMAS_ICONE } from "@/lib/pagamento-icons";
import { cn } from "@/lib/utils";

export type DadosVendedor = { loja: string; whatsapp: string; pix_tipo: string; pix_chave: string; formas_pagamento: string[] };

export function validarVendedor(d: DadosVendedor): string | null {
  if (d.whatsapp.replace(/\D/g, "").length < 10) return "Informe um WhatsApp válido com DDD.";
  if (!d.formas_pagamento.length) return "Escolha pelo menos uma forma de pagamento.";
  if (d.formas_pagamento.includes("Pix") && !d.pix_chave.trim()) return "Informe sua chave Pix.";
  return null;
}

export function SellerFields({ v, onChange }: { v: DadosVendedor; onChange: (v: DadosVendedor) => void }) {
  const set = (p: Partial<DadosVendedor>) => onChange({ ...v, ...p });
  const toggle = (f: string) =>
    set({ formas_pagamento: v.formas_pagamento.includes(f) ? v.formas_pagamento.filter((x) => x !== f) : [...v.formas_pagamento, f] });

  return (
    <div className="space-y-4 rounded-2xl border border-border bg-muted/50 p-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="loja">Nome da loja (opcional)</Label>
          <Input id="loja" value={v.loja} onChange={(e) => set({ loja: e.target.value })} placeholder="Doces da Ana" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="whatsapp">WhatsApp *</Label>
          <Input id="whatsapp" value={v.whatsapp} onChange={(e) => set({ whatsapp: e.target.value })} placeholder="(71) 99999-0000" inputMode="tel" />
        </div>
      </div>
      <div>
        <Label>Formas de pagamento que você aceita *</Label>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {FORMAS_PAGAMENTO.map((f) => {
            const Icone = FORMAS_ICONE[f];
            const ativo = v.formas_pagamento.includes(f);
            return (
              <label key={f} className={cn(
                "flex cursor-pointer items-center gap-2.5 rounded-xl border px-3 py-2.5 text-sm font-medium transition-all duration-200",
                ativo
                  ? "border-primary/55 bg-primary/10 text-primary-deep shadow-soft"
                  : "border-border bg-card hover:-translate-y-px hover:border-primary/40 hover:bg-secondary/60",
              )}>
                <Checkbox checked={ativo} onCheckedChange={() => toggle(f)} className="rounded-md data-[state=checked]:bg-gradient-warm data-[state=checked]:border-transparent" />
                {Icone ? <Icone className="size-4 shrink-0 opacity-70" /> : null}
                {f}
              </label>
            );
          })}
        </div>
      </div>
      {v.formas_pagamento.includes("Pix") && (
        <div className="grid gap-4 sm:grid-cols-[160px_1fr]">
          <div className="space-y-1.5">
            <Label htmlFor="pix_tipo">Tipo de chave</Label>
            <select id="pix_tipo" value={v.pix_tipo} onChange={(e) => set({ pix_tipo: e.target.value })}
              className="h-10 w-full rounded-md border border-input bg-card px-3 text-sm">
              <option value="">Selecione</option>
              {TIPOS_PIX.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pix_chave">Chave Pix *</Label>
            <Input id="pix_chave" value={v.pix_chave} onChange={(e) => set({ pix_chave: e.target.value })} placeholder="Sua chave Pix" />
          </div>
        </div>
      )}
    </div>
  );
}
