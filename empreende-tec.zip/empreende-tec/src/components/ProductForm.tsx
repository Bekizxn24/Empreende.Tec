import { useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ImagePlus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { enviarImagem, listarCategorias, type ProdutoItem } from "@/lib/data";

const sel = "h-10 w-full rounded-md border border-input bg-card px-3 text-sm";

export function ProductForm({ produto }: { produto?: ProdutoItem }) {
  const { session } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const categorias = useQuery({ queryKey: ["categorias"], queryFn: listarCategorias });
  const [f, setF] = useState({
    nome: produto?.nome ?? "", descricao: produto?.descricao ?? "", tipo: produto?.tipo ?? "Produto",
    categoria_id: String(produto?.categoria_id ?? ""), preco: produto ? String(produto.preco) : "",
    quantidade: produto ? String(produto.quantidade) : "1", local_entrega: produto?.local_entrega ?? "",
  });
  const [arquivo, setArquivo] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(produto?.imagem ?? null);
  const [salvando, setSalvando] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    const preco = Number(f.preco.replace(",", "."));
    const quantidade = parseInt(f.quantidade, 10);
    if (!f.nome.trim() || !f.categoria_id || isNaN(preco) || preco < 0 || isNaN(quantidade) || quantidade < 0)
      return void toast.error("Preencha nome, categoria, preço e quantidade corretamente.");
    setSalvando(true);
    try {
      const uid = session!.user.id;
      const imagem_url = arquivo ? await enviarImagem(uid, arquivo) : produto?.imagem_url ?? "";
      const dados = { nome: f.nome.trim(), descricao: f.descricao.trim(), tipo: f.tipo, categoria_id: Number(f.categoria_id), preco, quantidade, local_entrega: f.local_entrega.trim(), imagem_url };
      const { error } = produto
        ? await supabase.from("produtos").update(dados).eq("id", produto.id)
        : await supabase.from("produtos").insert({ ...dados, vendedor_id: uid });
      if (error) throw error;
      await qc.invalidateQueries();
      toast.success(produto ? "Anúncio atualizado." : "Anúncio publicado!");
      navigate({ to: "/painel" });
    } catch {
      toast.error("Não foi possível salvar. Verifique se sua conta é de vendedor.");
    } finally {
      setSalvando(false);
    }
  }

  return (
    <form onSubmit={salvar} className="grid gap-6 rounded-3xl border border-border bg-card p-6 shadow-soft md:grid-cols-[260px_1fr] md:p-8">
      <label className="flex aspect-square cursor-pointer flex-col items-center justify-center gap-2 overflow-hidden rounded-2xl border-2 border-dashed border-border bg-muted text-sm text-muted-foreground hover:border-primary">
        {preview ? <img src={preview} alt="" className="h-full w-full object-cover" /> : <><ImagePlus className="size-8" /> Adicionar foto</>}
        <input type="file" accept="image/*" className="hidden" onChange={(e) => {
          const file = e.target.files?.[0]; if (!file) return;
          if (file.size > 5 * 1024 * 1024) return void toast.error("A imagem deve ter no máximo 5 MB.");
          setArquivo(file); setPreview(URL.createObjectURL(file));
        }} />
      </label>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1.5 sm:col-span-2"><Label htmlFor="nome">Nome *</Label><Input id="nome" value={f.nome} onChange={set("nome")} maxLength={80} /></div>
        <div className="space-y-1.5"><Label htmlFor="tipo">Tipo</Label>
          <select id="tipo" className={sel} value={f.tipo} onChange={set("tipo")}><option>Produto</option><option>Serviço</option></select></div>
        <div className="space-y-1.5"><Label htmlFor="cat">Categoria *</Label>
          <select id="cat" className={sel} value={f.categoria_id} onChange={set("categoria_id")}>
            <option value="">Selecione</option>
            {categorias.data?.map((c) => <option key={c.id} value={c.id}>{c.icone} {c.nome}</option>)}
          </select></div>
        <div className="space-y-1.5"><Label htmlFor="preco">Preço (R$) *</Label><Input id="preco" inputMode="decimal" value={f.preco} onChange={set("preco")} placeholder="4,50" /></div>
        <div className="space-y-1.5"><Label htmlFor="qtd">Quantidade disponível *</Label><Input id="qtd" type="number" min={0} value={f.quantidade} onChange={set("quantidade")} /></div>
        <div className="space-y-1.5 sm:col-span-2"><Label htmlFor="local">Local de entrega</Label><Input id="local" value={f.local_entrega} onChange={set("local_entrega")} placeholder="Senac — intervalo da manhã" /></div>
        <div className="space-y-1.5 sm:col-span-2"><Label htmlFor="desc">Descrição</Label><Textarea id="desc" rows={5} value={f.descricao} onChange={set("descricao")} maxLength={1000} /></div>
        <div className="flex gap-3 sm:col-span-2">
          <Button type="submit" size="lg" disabled={salvando}>{salvando ? "Salvando…" : produto ? "Salvar alterações" : "Publicar anúncio"}</Button>
          <Button type="button" variant="outline" size="lg" onClick={() => navigate({ to: "/painel" })}>Cancelar</Button>
        </div>
      </div>
    </form>
  );
}
