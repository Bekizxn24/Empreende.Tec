import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-3">
        <div>
          <p className="font-display text-2xl font-bold">Empreende Tec</p>
          <p className="mt-2 max-w-xs text-sm text-ink-foreground/70">
            A vitrine dos jovens empreendedores do Senac. Compre direto de quem faz.
          </p>
        </div>
        <div className="text-sm">
          <p className="mb-3 font-semibold">Navegue</p>
          <ul className="space-y-2 text-ink-foreground/70">
            <li><Link to="/produtos" className="hover:text-ink-foreground">Vitrine</Link></li>
            <li><Link to="/sobre" className="hover:text-ink-foreground">Sobre o projeto</Link></li>
            <li><Link to="/auth" search={{ modo: "cadastro" }} className="hover:text-ink-foreground">Quero vender</Link></li>
          </ul>
        </div>
        <div className="text-sm text-ink-foreground/70">
          <p className="mb-3 font-semibold text-ink-foreground">Como funciona</p>
          <p>Escolha o produto, pague com a forma aceita pelo vendedor e envie o comprovante pelo WhatsApp dele.</p>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10 py-5 text-center text-xs text-ink-foreground/50">
        © {new Date().getFullYear()} Empreende Tec · Projeto dos alunos do Senac
      </div>
    </footer>
  );
}
