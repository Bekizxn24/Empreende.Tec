import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

type Size = "sm" | "md" | "lg";

const chipVariants = cva(
  "group/chip relative inline-flex cursor-pointer select-none items-center gap-2 whitespace-nowrap rounded-full border font-semibold outline-none transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      ativo: {
        true: "-translate-y-px border-transparent bg-gradient-warm text-primary-foreground shadow-glow btn-sheen",
        false:
          "border-border bg-card text-foreground shadow-soft hover:-translate-y-px hover:border-primary/50 hover:text-primary-deep hover:shadow-lift",
      },
      size: {
        sm: "px-3 py-1.5 text-xs",
        md: "px-4 py-2 text-sm",
        lg: "px-5 py-2.5 text-[0.95rem]",
      },
    },
    defaultVariants: { ativo: false, size: "md" },
  },
);

const tileVariants = cva(
  "flex shrink-0 items-center justify-center rounded-full transition-all duration-200 [&_svg]:size-3.5",
  {
    variants: {
      ativo: {
        true: "bg-primary-foreground/25 text-primary-foreground ring-1 ring-primary-foreground/45",
        false:
          "bg-secondary text-primary-deep group-hover/chip:bg-gradient-warm group-hover/chip:text-primary-foreground group-hover/chip:ring-1 group-hover/chip:ring-primary/35",
      },
      size: {
        sm: "size-5 text-[0.7rem]",
        md: "size-6 text-sm",
        lg: "size-7 text-base",
      },
    },
    defaultVariants: { ativo: false, size: "md" },
  },
);

const ChipCtx = React.createContext<{ ativo: boolean; size: Size }>({ ativo: false, size: "md" });

export type ChipProps = React.ComponentProps<"button"> &
  VariantProps<typeof chipVariants> & { asChild?: boolean };

/**
 * Filtro/categoria clicável. Aceita `asChild` para virar um Link real:
 * nesse caso o conteúdo (incluindo <ChipIcon />) vai dentro do filho.
 */
export function Chip({ className, ativo, size, asChild = false, type, children, ...props }: ChipProps) {
  const Comp = asChild ? Slot : "button";
  return (
    <ChipCtx.Provider value={{ ativo: !!ativo, size: size ?? "md" }}>
      <Comp
        {...(asChild ? {} : { type: type ?? ("button" as const) })}
        className={cn(chipVariants({ ativo, size, className }))}
        {...props}
      >
        {children}
      </Comp>
    </ChipCtx.Provider>
  );
}

/** Ícone em pastilha redonda dentro do Chip; herda o estado do Chip. */
export function ChipIcon({ className, children, ...props }: React.ComponentProps<"span">) {
  const { ativo, size } = React.useContext(ChipCtx);
  return (
    <span aria-hidden className={cn(tileVariants({ ativo, size, className }))} {...props}>
      {children}
    </span>
  );
}

export { chipVariants };
