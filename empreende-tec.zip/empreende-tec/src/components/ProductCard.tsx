import { Link } from "@tanstack/react-router";
import { ImageOff } from "lucide-react";
import type { ProdutoItem } from "@/lib/data";
import { brl } from "@/lib/format";

export function ProductCard({ p }: { p: ProdutoItem }) {
  const esgotado = p.quantidade <= 0;
  return (
    <Link
      to="/produto/$id"
      params={{ id: p.id }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        {p.imagem ? (
          <img src={p.imagem} alt={p.nome} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="flex h-full items-center justify-center text-5xl">{p.categoria?.icone ?? <ImageOff className="text-muted-foreground" />}</div>
        )}
        <span className="absolute left-3 top-3 rounded-full bg-card/90 px-3 py-1 text-xs font-semibold backdrop-blur">
          {p.categoria?.icone} {p.categoria?.nome}
        </span>
        {esgotado && (
          <span className="absolute right-3 top-3 rounded-full bg-ink px-3 py-1 text-xs font-semibold text-ink-foreground">Esgotado</span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{p.vendedor?.loja || p.vendedor?.nome}</p>
        <h3 className="line-clamp-1 text-lg font-semibold">{p.nome}</h3>
        <p className="line-clamp-2 text-sm text-muted-foreground">{p.descricao}</p>
        <p className="mt-auto pt-3 font-display text-xl font-bold text-wine">{brl(p.preco)}</p>
      </div>
    </Link>
  );
}

export function ProductGridSkeleton({ n = 6 }: { n?: number }) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} className="h-80 animate-pulse rounded-2xl bg-muted" />
      ))}
    </div>
  );
}
