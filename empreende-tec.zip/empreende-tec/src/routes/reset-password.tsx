import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Criar nova senha — Empreende Tec" },
      { name: "description", content: "Defina uma nova senha para sua conta no Empreende Tec." },
      { property: "og:title", content: "Criar nova senha — Empreende Tec" },
      { property: "og:description", content: "Defina uma nova senha para sua conta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [senha, setSenha] = useState("");
  const [confirma, setConfirma] = useState("");
  const [pronto, setPronto] = useState(false);
  const [carregando, setCarregando] = useState(false);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((e) => { if (e === "PASSWORD_RECOVERY" || e === "SIGNED_IN") setPronto(true); });
    supabase.auth.getSession().then(({ data: s }) => { if (s.session) setPronto(true); });
    return () => data.subscription.unsubscribe();
  }, []);

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    if (senha.length < 6) return void toast.error("A senha precisa ter pelo menos 6 caracteres.");
    if (senha !== confirma) return void toast.error("As senhas não coincidem.");
    setCarregando(true);
    const { error } = await supabase.auth.updateUser({ password: senha });
    setCarregando(false);
    if (error) return void toast.error("Não foi possível alterar a senha. Peça um novo link.");
    toast.success("Senha alterada com sucesso!");
    navigate({ to: "/painel" });
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <div className="rounded-3xl border border-border bg-card p-8 shadow-lift">
        <h1 className="text-3xl">Criar nova senha</h1>
        {!pronto ? (
          <p className="mt-4 text-muted-foreground">Abra esta página pelo link enviado ao seu e-mail. Se o link expirou, peça um novo na tela de login.</p>
        ) : (
          <form onSubmit={salvar} className="mt-6 space-y-4">
            <div className="space-y-1.5"><Label htmlFor="s">Nova senha</Label><Input id="s" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} autoComplete="new-password" /></div>
            <div className="space-y-1.5"><Label htmlFor="c">Confirmar senha</Label><Input id="c" type="password" value={confirma} onChange={(e) => setConfirma(e.target.value)} autoComplete="new-password" /></div>
            <Button type="submit" className="w-full" size="lg" disabled={carregando}>{carregando ? "Salvando…" : "Salvar nova senha"}</Button>
          </form>
        )}
      </div>
    </div>
  );
}
