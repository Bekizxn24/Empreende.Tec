import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Check, Copy, MapPin, MessageCircle, Minus, Plus } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Chip, ChipIcon } from "@/components/Chip";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { buscarProduto } from "@/lib/data";
import { brl, linkWhatsapp, mensagemPedido } from "@/lib/format";
import { FORMAS_ICONE } from "@/lib/pagamento-icons";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/produto/$id")({
  head: () => ({
    meta: [
      { title: "Anúncio — Empreende Tec" },
      { name: "description", content: "Veja detalhes, formas de pagamento e compre direto com o vendedor pelo WhatsApp." },
      { property: "og:title", content: "Anúncio no Empreende Tec" },
      { property: "og:description", content: "Compre direto com o empreendedor pelo WhatsApp." },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Produto,
});

function Produto() {
  const { id } = Route.useParams();
  const { data: p, isLoading } = useQuery({ queryKey: ["produto", id], queryFn: () => buscarProduto(id) });

  useEffect(() => { void supabase.rpc("contar_visita", { _id: id }); }, [id]);

  if (isLoading) return <div className="mx-auto max-w-6xl px-4 py-16"><div className="h-96 animate-pulse rounded-3xl bg-muted" /></div>;
  if (!p) return (
    <div className="mx-auto max-w-xl px-4 py-24 text-center">
      <h1 className="text-3xl">Anúncio não encontrado</h1>
      <Button className="mt-6" asChild><Link to="/produtos">Voltar à vitrine</Link></Button>
    </div>
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <Link to="/produtos" className="inline-flex items-center gap-1 text-sm font-medium text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" /> Vitrine</Link>
      <div className="mt-6 grid gap-10 lg:grid-cols-[1.1fr_1fr]">
        <div className="overflow-hidden rounded-3xl border border-border bg-muted shadow-soft">
          {p.imagem ? <img src={p.imagem} alt={p.nome} className="aspect-square w-full object-cover" /> :
            <div className="flex aspect-square items-center justify-center text-8xl">{p.categoria?.icone}</div>}
        </div>
        <div>
          <div className="flex flex-wrap gap-2 text-xs font-semibold">
            <span className="rounded-full bg-secondary px-3 py-1 ring-1 ring-border">{p.categoria?.icone} {p.categoria?.nome}</span>
            <span className="rounded-full bg-secondary px-3 py-1 ring-1 ring-border">{p.tipo}</span>
            <span className={cn("rounded-full px-3 py-1 ring-1", p.quantidade > 0 ? "bg-success/15 text-success ring-success/25" : "bg-ink text-ink-foreground ring-ink")}>
              {p.quantidade > 0 ? `${p.quantidade} disponível(is)` : "Esgotado"}
            </span>
          </div>
          <h1 className="mt-4 text-4xl md:text-5xl">{p.nome}</h1>
          <p className="mt-2 text-sm text-muted-foreground">por <span className="font-semibold text-foreground">{p.vendedor?.loja || p.vendedor?.nome}</span></p>
          <p className="mt-6 font-display text-4xl font-extrabold text-wine">{brl(p.preco)}</p>
          <p className="mt-6 whitespace-pre-line leading-relaxed text-muted-foreground">{p.descricao}</p>
          {p.local_entrega && <p className="mt-4 flex items-center gap-2 text-sm"><MapPin className="size-4 text-primary-deep" /> {p.local_entrega}</p>}
          <Compra p={p} />
        </div>
      </div>
    </div>
  );
}

type Prod = NonNullable<Awaited<ReturnType<typeof buscarProduto>>>;

function Compra({ p }: { p: Prod }) {
  const { session, perfil } = useAuth();
  const vendedor = useQuery({
    queryKey: ["vendedor", p.vendedor_id],
    enabled: !!session,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("nome,loja,whatsapp,pix_tipo,pix_chave,formas_pagamento").eq("id", p.vendedor_id).single();
      return data;
    },
  });
  const [qtd, setQtd] = useState(1);
  const [forma, setForma] = useState<string>("");
  const [msg, setMsg] = useState("");
  const [copiado, setCopiado] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const total = Number(p.preco) * qtd;

  const formas = vendedor.data?.formas_pagamento ?? [];
  useEffect(() => { if (!forma && formas.length) setForma(formas[0] ?? ""); }, [formas, forma]);

  if (!session) return (
    <div className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-soft">
      <p className="font-semibold">Entre para comprar</p>
      <p className="mt-1 text-sm text-muted-foreground">Você verá as formas de pagamento e o Pix do vendedor.</p>
      <div className="mt-4 flex gap-2">
        <Button asChild><Link to="/auth">Entrar</Link></Button>
        <Button variant="outline" asChild><Link to="/auth" search={{ modo: "cadastro" }}>Criar conta</Link></Button>
      </div>
    </div>
  );
  if (session.user.id === p.vendedor_id) return (
    <div className="mt-8 rounded-2xl border border-border bg-card p-6">
      <p className="font-semibold">Este anúncio é seu.</p>
      <Button className="mt-3" variant="outline" asChild><Link to="/anuncio/$id" params={{ id: p.id }}>Editar anúncio</Link></Button>
    </div>
  );
  if (p.quantidade <= 0) return <div className="mt-8 rounded-2xl bg-muted p-6 font-semibold">Este item está esgotado no momento.</div>;
  const v = vendedor.data;
  if (vendedor.isLoading || !v) return <div className="mt-8 h-48 animate-pulse rounded-2xl bg-muted" />;

  async function copiar() {
    await navigator.clipboard.writeText(v!.pix_chave);
    setCopiado(true); toast.success("Chave Pix copiada!");
    setTimeout(() => setCopiado(false), 2000);
  }

  async function finalizar() {
    if (!forma) return void toast.error("Escolha a forma de pagamento.");
    if (!v!.whatsapp) return void toast.error("Este vendedor ainda não cadastrou o WhatsApp.");
    setEnviando(true);
    const janela = window.open("", "_blank");
    const { error } = await supabase.from("pedidos").insert({
      produto_id: p.id, comprador_id: session!.user.id, vendedor_id: p.vendedor_id,
      quantidade: qtd, forma_pagamento: forma, total, mensagem: msg,
    });
    setEnviando(false);
    if (error) { janela?.close(); return void toast.error("Não foi possível registrar o pedido."); }
    let texto = mensagemPedido({ vendedor: v!.nome, produto: p.nome, quantidade: qtd, total, forma, comprador: perfil?.nome || "um comprador" });
    if (msg) texto += `\n\nObs.: ${msg}`;
    const url = linkWhatsapp(v!.whatsapp, texto);
    if (janela) janela.location.href = url; else window.location.href = url;
    toast.success("Pedido registrado! Envie o comprovante no WhatsApp.");
  }

  return (
    <div className="mt-8 rounded-2xl border border-border bg-card p-6 shadow-soft">
      <div className="flex items-center justify-between">
        <p className="font-semibold">Quantidade</p>
        <div className="flex items-center gap-1 rounded-full border border-border bg-card p-1 shadow-soft">
          <Button size="icon" variant="ghost" className="size-8 active:scale-95" onClick={() => setQtd(Math.max(1, qtd - 1))} aria-label="Diminuir"><Minus /></Button>
          <span className="w-8 text-center font-semibold tabular-nums">{qtd}</span>
          <Button size="icon" variant="ghost" className="size-8 active:scale-95" onClick={() => setQtd(Math.min(p.quantidade, qtd + 1))} aria-label="Aumentar"><Plus /></Button>
        </div>
      </div>

      <p className="mt-6 font-semibold">Forma de pagamento</p>
      {formas.length ? (
        <div className="mt-2 flex flex-wrap gap-2.5">
          {formas.map((f) => {
            const Icone = FORMAS_ICONE[f];
            return (
              <Chip key={f} ativo={forma === f} onClick={() => setForma(f)}>
                <ChipIcon>{Icone ? <Icone /> : null}</ChipIcon>
                {f}
              </Chip>
            );
          })}
        </div>
      ) : <p className="mt-1 text-sm text-muted-foreground">O vendedor ainda não definiu formas de pagamento — combine pelo WhatsApp.</p>}

      {forma === "Pix" && v.pix_chave && (
        <div className="mt-5 rounded-xl border border-dashed border-primary/50 bg-primary/5 p-4">
          <p className="text-xs font-semibold uppercase tracking-wider text-primary-deep">Pix · {v.pix_tipo || "Chave"}</p>
          <div className="mt-1 flex items-center justify-between gap-3">
            <p className="break-all font-mono text-sm font-semibold">{v.pix_chave}</p>
            <Button size="sm" variant="outline" onClick={copiar}>{copiado ? <Check /> : <Copy />} {copiado ? "Copiado" : "Copiar"}</Button>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Favorecido: {v.nome}. Pague {brl(total)} e depois envie o comprovante.</p>
        </div>
      )}

      <Textarea value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Observação para o vendedor (opcional)" className="mt-5" maxLength={300} />

      <div className="mt-6 flex items-center justify-between border-t border-border pt-5">
        <div>
          <p className="text-xs text-muted-foreground">Total</p>
          <p className="font-display text-2xl font-bold">{brl(total)}</p>
        </div>
        <Button variant="whatsapp" size="lg" onClick={finalizar} disabled={enviando}>
          <MessageCircle /> {forma === "Pix" ? "Enviar comprovante" : "Pedir no WhatsApp"}
        </Button>
      </div>
    </div>
  );
}
