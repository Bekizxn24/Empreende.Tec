import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LayoutGrid, Package, Search, Tags, Wrench } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Chip, ChipIcon } from "@/components/Chip";
import { Input } from "@/components/ui/input";
import { ProductCard, ProductGridSkeleton } from "@/components/ProductCard";
import { listarCategorias, listarProdutos } from "@/lib/data";

type Busca = { q?: string | undefined; tipo?: string | undefined; categoria?: string | undefined };

export const Route = createFileRoute("/produtos")({
  validateSearch: (s: { modo?: unknown; q?: unknown; tipo?: unknown; categoria?: unknown }): Busca => ({
    q: typeof s.q === "string" && s.q ? s.q : undefined,
    tipo: s.tipo === "Produto" || s.tipo === "Serviço" ? s.tipo : undefined,
    categoria: s.categoria ? String(s.categoria) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Vitrine — Empreende Tec" },
      { name: "description", content: "Explore produtos e serviços dos empreendedores do Senac. Filtre por categoria e tipo." },
      { property: "og:title", content: "Vitrine — Empreende Tec" },
      { property: "og:description", content: "Produtos e serviços dos empreendedores do Senac." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Produtos,
});

function Produtos() {
  const f = Route.useSearch();
  const navigate = useNavigate({ from: "/produtos" });
  const [texto, setTexto] = useState(f.q ?? "");
  const produtos = useQuery({ queryKey: ["produtos", f], queryFn: () => listarProdutos(f) });
  const categorias = useQuery({ queryKey: ["categorias"], queryFn: listarCategorias });
  const set = (p: Partial<Busca>) => navigate({ search: (s) => ({ ...s, ...p }) });

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="text-4xl md:text-5xl">Vitrine</h1>
      <p className="mt-2 text-muted-foreground">Tudo o que nossos empreendedores estão oferecendo.</p>

      <form onSubmit={(e) => { e.preventDefault(); set({ q: texto || undefined }); }} className="relative mt-8 max-w-xl">
        <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input value={texto} onChange={(e) => setTexto(e.target.value)} placeholder="Buscar brigadeiro, camiseta, aula…" className="h-12 rounded-full bg-card pl-11 pr-28 shadow-soft" />
        <Button type="submit" size="sm" className="absolute right-1.5 top-1/2 -translate-y-1/2 h-9 px-4">Buscar</Button>
      </form>

      <div className="mt-7 flex flex-wrap gap-2.5">
        <Chip ativo={!f.tipo} onClick={() => set({ tipo: undefined })}><ChipIcon><LayoutGrid /></ChipIcon>Todos</Chip>
        <Chip ativo={f.tipo === "Produto"} onClick={() => set({ tipo: "Produto" })}><ChipIcon><Package /></ChipIcon>Produtos</Chip>
        <Chip ativo={f.tipo === "Serviço"} onClick={() => set({ tipo: "Serviço" })}><ChipIcon><Wrench /></ChipIcon>Serviços</Chip>
      </div>
      <div className="mt-3 flex flex-wrap gap-2.5">
        <Chip ativo={!f.categoria} onClick={() => set({ categoria: undefined })}><ChipIcon><Tags /></ChipIcon>Todas as categorias</Chip>
        {categorias.data?.map((c) => (
          <Chip key={c.id} ativo={f.categoria === String(c.id)} onClick={() => set({ categoria: String(c.id) })}>
            <ChipIcon>{c.icone}</ChipIcon>{c.nome}
          </Chip>
        ))}
      </div>

      <div className="mt-10">
        {produtos.isLoading ? <ProductGridSkeleton /> : produtos.data?.length ? (
          <>
            <p className="mb-4 text-sm text-muted-foreground">{produtos.data.length} anúncio(s)</p>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {produtos.data.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          </>
        ) : (
          <div className="rounded-3xl border border-dashed border-border bg-card p-12 text-center text-muted-foreground">
            Nenhum anúncio encontrado com esses filtros.
          </div>
        )}
      </div>
    </div>
  );
}
