import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, MessageCircle, QrCode, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Chip, ChipIcon } from "@/components/Chip";
import { ProductCard, ProductGridSkeleton } from "@/components/ProductCard";
import { listarCategorias, listarProdutos } from "@/lib/data";
import heroImg from "@/assets/hero-empreendedores.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Empreende Tec — Compre direto dos empreendedores do Senac" },
      { name: "description", content: "Doces, artesanato, roupas e serviços feitos pelos alunos do Senac. Pague por Pix e envie o comprovante pelo WhatsApp." },
      { property: "og:title", content: "Empreende Tec — Compre direto dos empreendedores do Senac" },
      { property: "og:description", content: "Doces, artesanato, roupas e serviços feitos pelos alunos do Senac." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const produtos = useQuery({ queryKey: ["produtos", "destaques"], queryFn: () => listarProdutos() });
  const categorias = useQuery({ queryKey: ["categorias"], queryFn: listarCategorias });

  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-glow" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 md:grid-cols-2 md:py-24">
          <div className="animate-rise">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold text-primary-deep">
              <Sparkles className="size-3.5" /> Feito por alunos do Senac
            </span>
            <h1 className="mt-5 text-5xl leading-[1.02] md:text-6xl">
              Compre de quem <span className="text-gradient-warm">faz acontecer.</span>
            </h1>
            <p className="mt-5 max-w-md text-lg text-muted-foreground">
              Doces, artesanato, roupas e serviços de jovens empreendedores. Pague por Pix e fale direto com o vendedor no WhatsApp.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button variant="hero" size="lg" asChild>
                <Link to="/produtos">Ver a vitrine <ArrowRight /></Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/auth" search={{ modo: "cadastro" }}>Quero vender</Link>
              </Button>
            </div>
          </div>
          <div className="relative animate-rise [animation-delay:120ms]">
            <img src={heroImg} alt="Jovens empreendedores com seus produtos" width={1280} height={1024} className="aspect-[5/4] w-full rounded-3xl object-cover shadow-lift" />
            <div className="absolute -bottom-6 -left-4 flex items-center gap-3 rounded-2xl border border-border bg-card p-4 shadow-lift">
              <span className="flex size-10 items-center justify-center rounded-full bg-success text-success-foreground"><QrCode className="size-5" /></span>
              <div className="text-sm">
                <p className="font-semibold">Pix direto ao vendedor</p>
                <p className="text-muted-foreground">Sem taxas, sem intermediário</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap gap-2.5">
          {categorias.data?.map((c) => (
            <Chip key={c.id} asChild size="lg">
              <Link to="/produtos" search={{ categoria: String(c.id) }}>
                <ChipIcon>{c.icone}</ChipIcon>
                {c.nome}
              </Link>
            </Chip>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl md:text-4xl">Novidades na vitrine</h2>
            <p className="mt-1 text-muted-foreground">Os anúncios mais recentes dos nossos empreendedores.</p>
          </div>
          <Link to="/produtos" className="hidden text-sm font-semibold text-primary-deep hover:underline sm:block">Ver tudo →</Link>
        </div>
        {produtos.isLoading ? (
          <ProductGridSkeleton />
        ) : produtos.data?.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {produtos.data.slice(0, 6).map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        ) : (
          <div className="rounded-3xl border border-dashed border-border bg-card p-12 text-center">
            <p className="font-display text-2xl font-bold">A vitrine está esperando você</p>
            <p className="mt-2 text-muted-foreground">Seja o primeiro a anunciar um produto ou serviço.</p>
            <Button className="mt-6" asChild><Link to="/auth" search={{ modo: "cadastro" }}>Criar conta de vendedor</Link></Button>
          </div>
        )}
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="text-center text-3xl md:text-4xl">Como comprar</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { icon: ShieldCheck, t: "1. Crie sua conta", d: "Cadastro rápido e gratuito como comprador." },
            { icon: QrCode, t: "2. Pague do jeito aceito", d: "Pix, dinheiro ou cartão — o vendedor escolhe as formas." },
            { icon: MessageCircle, t: "3. Envie o comprovante", d: "Um toque abre o WhatsApp do vendedor com o pedido pronto." },
          ].map(({ icon: Icon, t, d }) => (
            <div key={t} className="rounded-2xl border border-border bg-card p-6 shadow-soft">
              <span className="flex size-11 items-center justify-center rounded-xl bg-gradient-warm text-primary-foreground"><Icon className="size-5" /></span>
              <h3 className="mt-4 text-xl">{t}</h3>
              <p className="mt-1 text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
