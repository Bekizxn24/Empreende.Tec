import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/sobre")({
  head: () => ({
    meta: [
      { title: "Sobre — Empreende Tec" },
      { name: "description", content: "Conheça o Empreende Tec, a vitrine dos alunos empreendedores do Senac." },
      { property: "og:title", content: "Sobre o Empreende Tec" },
      { property: "og:description", content: "A vitrine dos alunos empreendedores do Senac." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Sobre,
});

function Sobre() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <p className="text-sm font-semibold uppercase tracking-widest text-primary-deep">Sobre o projeto</p>
      <h1 className="mt-3 text-4xl md:text-5xl">Uma vitrine para quem está começando a empreender.</h1>
      <div className="mt-8 space-y-5 text-lg leading-relaxed text-muted-foreground">
        <p>O Empreende Tec nasceu no Senac para dar visibilidade aos produtos e serviços criados pelos alunos — de doces caseiros a artesanato, roupas e serviços.</p>
        <p>Aqui o comprador fala direto com quem produz. O vendedor define como quer receber (Pix, dinheiro, cartão) e o pagamento vai direto para ele, sem intermediários.</p>
        <p>Depois de pagar, o comprador envia o comprovante pelo WhatsApp do vendedor e os dois combinam a entrega.</p>
      </div>
      <div className="mt-10 flex gap-3">
        <Button asChild><Link to="/produtos">Explorar a vitrine</Link></Button>
        <Button variant="outline" asChild><Link to="/auth" search={{ modo: "cadastro" }}>Começar a vender</Link></Button>
      </div>
    </div>
  );
}
