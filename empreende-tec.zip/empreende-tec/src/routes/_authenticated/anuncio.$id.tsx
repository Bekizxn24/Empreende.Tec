import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ProductForm } from "@/components/ProductForm";
import { buscarProduto } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/anuncio/$id")({
  head: () => ({ meta: [{ title: "Editar anúncio — Empreende Tec" }, { name: "description", content: "Edite seu anúncio." }, { property: "og:title", content: "Editar anúncio — Empreende Tec" }, { property: "og:description", content: "Edite seu anúncio." }] }),
  component: Editar,
});

function Editar() {
  const { id } = Route.useParams();
  const { data, isLoading } = useQuery({ queryKey: ["produto", id], queryFn: () => buscarProduto(id) });
  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      <h1 className="mb-8 text-4xl">Editar anúncio</h1>
      {isLoading ? <div className="h-96 animate-pulse rounded-3xl bg-muted" /> : data ? <ProductForm produto={data} /> : <p>Anúncio não encontrado.</p>}
    </div>
  );
}
