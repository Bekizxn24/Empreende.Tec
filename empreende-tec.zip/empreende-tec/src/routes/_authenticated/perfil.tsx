import { createFileRoute } from "@tanstack/react-router";
import { ShoppingBag, Store } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SellerFields, validarVendedor, type DadosVendedor } from "@/components/SellerFields";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({ meta: [{ title: "Meu perfil — Empreende Tec" }, { name: "description", content: "Edite seus dados, Pix, WhatsApp e formas de pagamento." }, { property: "og:title", content: "Meu perfil — Empreende Tec" }, { property: "og:description", content: "Edite seus dados." }] }),
  component: Perfil,
});

function Perfil() {
  const { session, perfil, recarregarPerfil } = useAuth();
  const [nome, setNome] = useState("");
  const [tipo, setTipo] = useState<"comprador" | "vendedor">("comprador");
  const [vend, setVend] = useState<DadosVendedor>({ loja: "", whatsapp: "", pix_tipo: "", pix_chave: "", formas_pagamento: [] });
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (!perfil) return;
    setNome(perfil.nome); setTipo(perfil.tipo as "comprador" | "vendedor");
    setVend({ loja: perfil.loja, whatsapp: perfil.whatsapp, pix_tipo: perfil.pix_tipo, pix_chave: perfil.pix_chave, formas_pagamento: perfil.formas_pagamento });
  }, [perfil]);

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    if (!nome.trim()) return void toast.error("Informe seu nome.");
    if (tipo === "vendedor") { const erro = validarVendedor(vend); if (erro) return void toast.error(erro); }
    setSalvando(true);
    const { error } = await supabase.from("profiles").update({ nome: nome.trim(), tipo, ...vend }).eq("id", session!.user.id);
    setSalvando(false);
    if (error) return void toast.error("Não foi possível salvar.");
    await recarregarPerfil();
    toast.success("Perfil atualizado.");
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-4xl">Meu perfil</h1>
      <p className="mt-1 text-muted-foreground">{session?.user.email}</p>
      <form onSubmit={salvar} className="mt-8 space-y-6 rounded-3xl border border-border bg-card p-6 shadow-soft md:p-8">
        <div className="space-y-1.5"><Label htmlFor="nome">Nome</Label><Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} /></div>
        <div>
          <Label>Tipo de conta</Label>
          <div className="mt-2 grid grid-cols-2 gap-3">
            {([["comprador", "Comprador", ShoppingBag], ["vendedor", "Vendedor", Store]] as const).map(([t, l, Icon]) => (
              <button type="button" key={t} onClick={() => setTipo(t)} className={cn(
                "flex items-center justify-center gap-2 rounded-2xl border-2 p-3 text-sm font-semibold",
                tipo === t ? "border-primary bg-primary/5 text-primary-deep" : "border-border",
              )}><Icon className="size-5" /> {l}</button>
            ))}
          </div>
        </div>
        {tipo === "vendedor" && <SellerFields v={vend} onChange={setVend} />}
        <Button type="submit" size="lg" disabled={salvando}>{salvando ? "Salvando…" : "Salvar perfil"}</Button>
      </form>
    </div>
  );
}
