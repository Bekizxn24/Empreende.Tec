import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Eye, MessageCircle, Package, Pencil, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { listarProdutos } from "@/lib/data";
import { brl, linkWhatsapp } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({ meta: [{ title: "Meu painel — Empreende Tec" }, { name: "description", content: "Gerencie seus anúncios e pedidos." }, { property: "og:title", content: "Meu painel — Empreende Tec" }, { property: "og:description", content: "Seus anúncios e pedidos." }] }),
  component: Painel,
});

type Pedido = {
  id: string; quantidade: number; total: number; forma_pagamento: string; mensagem: string; created_at: string;
  produto: { nome: string } | null;
  comprador: { nome: string } | null;
  vendedor: { nome: string; whatsapp: string } | null;
};

function usePedidos(campo: "comprador_id" | "vendedor_id", uid?: string) {
  return useQuery({
    queryKey: ["pedidos", campo, uid],
    enabled: !!uid,
    queryFn: async () => {
      const { data } = await supabase.from("pedidos")
        .select("id,quantidade,total,forma_pagamento,mensagem,created_at,produto:produtos(nome),comprador:profiles!pedidos_comprador_id_fkey(nome),vendedor:profiles!pedidos_vendedor_id_fkey(nome,whatsapp)")
        .eq(campo, uid!).order("created_at", { ascending: false });
      return (data ?? []) as unknown as Pedido[];
    },
  });
}

const data = (s: string) => new Date(s).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });

function Stat({ icon: Icon, label, valor }: { icon: typeof Eye; label: string; valor: string | number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <Icon className="size-5 text-primary-deep" />
      <p className="mt-3 font-display text-3xl font-bold">{valor}</p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

function Painel() {
  const { session, perfil } = useAuth();
  const uid = session?.user.id;
  const vendedor = perfil?.tipo === "vendedor";
  const qc = useQueryClient();
  const itens = useQuery({ queryKey: ["produtos", "meus", uid], enabled: !!uid && vendedor, queryFn: () => listarProdutos({ vendedor: uid }) });
  const vendas = usePedidos("vendedor_id", vendedor ? uid : undefined);
  const compras = usePedidos("comprador_id", uid);

  async function excluir(id: string) {
    if (!confirm("Excluir este anúncio?")) return;
    const { error } = await supabase.from("produtos").delete().eq("id", id);
    if (error) return void toast.error("Não foi possível excluir.");
    toast.success("Anúncio excluído."); qc.invalidateQueries();
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-primary-deep">{vendedor ? "Painel do vendedor" : "Minha conta"}</p>
          <h1 className="mt-1 text-4xl">Olá, {perfil?.nome?.split(" ")[0] ?? ""} 👋</h1>
        </div>
        {vendedor && <Button variant="hero" asChild><Link to="/anuncio/novo"><Plus /> Novo anúncio</Link></Button>}
      </div>

      {vendedor && perfil && (!perfil.whatsapp || !perfil.formas_pagamento.length) && (
        <div className="mt-6 rounded-2xl border border-primary/40 bg-primary/10 p-4 text-sm">
          Complete seu WhatsApp e as formas de pagamento para receber pedidos. <Link to="/perfil" className="font-semibold underline">Completar perfil</Link>
        </div>
      )}

      {vendedor && (
        <>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <Stat icon={Package} label="Anúncios" valor={itens.data?.length ?? 0} />
            <Stat icon={Eye} label="Visualizações" valor={itens.data?.reduce((a, i) => a + i.views, 0) ?? 0} />
            <Stat icon={ShoppingBag} label="Pedidos recebidos" valor={vendas.data?.length ?? 0} />
          </div>

          <h2 className="mt-12 text-2xl">Meus anúncios</h2>
          <div className="mt-4 overflow-hidden rounded-2xl border border-border bg-card">
            {itens.data?.length ? itens.data.map((p) => (
              <div key={p.id} className="flex items-center gap-4 border-b border-border p-4 last:border-0">
                <div className="size-14 shrink-0 overflow-hidden rounded-xl bg-muted">
                  {p.imagem ? <img src={p.imagem} alt="" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-2xl">{p.categoria?.icone}</div>}
                </div>
                <div className="min-w-0 flex-1">
                  <Link to="/produto/$id" params={{ id: p.id }} className="font-semibold hover:underline">{p.nome}</Link>
                  <p className="text-sm text-muted-foreground">{brl(p.preco)} · {p.quantidade > 0 ? `${p.quantidade} em estoque` : "Esgotado"} · {p.views} visualizações</p>
                </div>
                <Button size="icon" variant="ghost" asChild aria-label="Editar"><Link to="/anuncio/$id" params={{ id: p.id }}><Pencil /></Link></Button>
                <Button size="icon" variant="ghost" onClick={() => excluir(p.id)} aria-label="Excluir"><Trash2 className="text-destructive" /></Button>
              </div>
            )) : <p className="p-8 text-center text-muted-foreground">{itens.isLoading ? "Carregando…" : "Você ainda não publicou nenhum anúncio."}</p>}
          </div>

          <h2 className="mt-12 text-2xl">Pedidos recebidos</h2>
          <ListaPedidos pedidos={vendas.data} vazio="Nenhum pedido recebido ainda." modo="venda" />
        </>
      )}

      <h2 className="mt-12 text-2xl">Minhas compras</h2>
      <ListaPedidos pedidos={compras.data} vazio="Você ainda não fez nenhum pedido." modo="compra" />
      {!vendedor && <Button className="mt-6" asChild><Link to="/produtos">Explorar a vitrine</Link></Button>}
    </div>
  );
}

function ListaPedidos({ pedidos, vazio, modo }: { pedidos?: Pedido[] | undefined; vazio: string; modo: "venda" | "compra" }) {
  if (!pedidos?.length) return <p className="mt-4 rounded-2xl border border-dashed border-border bg-card p-8 text-center text-muted-foreground">{vazio}</p>;
  return (
    <div className="mt-4 overflow-hidden rounded-2xl border border-border bg-card">
      {pedidos.map((p) => (
        <div key={p.id} className="flex flex-wrap items-center gap-4 border-b border-border p-4 last:border-0">
          <div className="min-w-0 flex-1">
            <p className="font-semibold">{p.quantidade}x {p.produto?.nome ?? "Anúncio removido"}</p>
            <p className="text-sm text-muted-foreground">
              {modo === "venda" ? `Comprador: ${p.comprador?.nome}` : `Vendedor: ${p.vendedor?.nome}`} · {p.forma_pagamento} · {data(p.created_at)}
            </p>
            {p.mensagem && <p className="mt-1 text-sm italic text-muted-foreground">“{p.mensagem}”</p>}
          </div>
          <p className="font-display text-lg font-bold text-wine">{brl(p.total)}</p>
          {modo === "compra" && p.vendedor?.whatsapp && (
            <Button size="sm" variant="whatsapp" asChild>
              <a href={linkWhatsapp(p.vendedor.whatsapp, `Olá, ${p.vendedor.nome}! Sobre meu pedido de ${p.quantidade}x ${p.produto?.nome}:`)} target="_blank" rel="noreferrer"><MessageCircle /> WhatsApp</a>
            </Button>
          )}
        </div>
      ))}
    </div>
  );
}
