import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ProductForm } from "@/components/ProductForm";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/anuncio/novo")({
  head: () => ({ meta: [{ title: "Novo anúncio — Empreende Tec" }, { name: "description", content: "Publique um produto ou serviço na vitrine." }, { property: "og:title", content: "Novo anúncio — Empreende Tec" }, { property: "og:description", content: "Publique na vitrine." }] }),
  component: () => {
    const { perfil } = useAuth();
    return (
      <div className="mx-auto max-w-5xl px-4 py-12">
        <h1 className="mb-8 text-4xl">Novo anúncio</h1>
        {perfil && perfil.tipo !== "vendedor" ? (
          <div className="rounded-3xl border border-border bg-card p-8">
            <p className="font-semibold">Sua conta é de comprador.</p>
            <p className="mt-1 text-muted-foreground">Para anunciar, ative o modo vendedor no seu perfil e cadastre seu WhatsApp e Pix.</p>
            <Button className="mt-4" asChild><Link to="/perfil">Ir para o perfil</Link></Button>
          </div>
        ) : <ProductForm />}
      </div>
    );
  },
});
