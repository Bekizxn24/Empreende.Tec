import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ShoppingBag, Store } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import logo from "@/assets/logo.png";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SellerFields, validarVendedor, type DadosVendedor } from "@/components/SellerFields";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

type Modo = "entrar" | "cadastro" | "esqueci";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: { modo?: unknown; q?: unknown; tipo?: unknown; categoria?: unknown }): { modo?: Modo | undefined } => ({
    modo: s.modo === "cadastro" || s.modo === "esqueci" ? s.modo : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Entrar ou criar conta — Empreende Tec" },
      { name: "description", content: "Acesse sua conta ou cadastre-se como comprador ou vendedor no Empreende Tec." },
      { property: "og:title", content: "Entrar no Empreende Tec" },
      { property: "og:description", content: "Cadastre-se como comprador ou vendedor." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function GoogleIcon() {
  return (
    <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path fill="var(--google-blue)" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/><path fill="var(--google-green)" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"/><path fill="var(--google-yellow)" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"/><path fill="var(--google-red)" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/></svg>
  );
}

function AuthPage() {
  const { modo = "entrar" } = Route.useSearch();
  const navigate = useNavigate();
  const { session } = useAuth();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [nome, setNome] = useState("");
  const [tipo, setTipo] = useState<"comprador" | "vendedor">("comprador");
  const [vend, setVend] = useState<DadosVendedor>({ loja: "", whatsapp: "", pix_tipo: "", pix_chave: "", formas_pagamento: ["Pix"] });
  const [carregando, setCarregando] = useState(false);
  const [enviado, setEnviado] = useState<string | null>(null);

  useEffect(() => { if (session) navigate({ to: "/painel" }); }, [session, navigate]);
  useEffect(() => setEnviado(null), [modo]);

  const ir = (m: Modo) => navigate({ to: "/auth", search: m === "entrar" ? {} : { modo: m } });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setCarregando(true);
    try {
      if (modo === "entrar") {
        const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
        if (error) throw new Error(error.message.includes("confirm") ? "Confirme seu e-mail antes de entrar." : "E-mail ou senha inválidos.");
        toast.success("Bem-vindo de volta!");
      } else if (modo === "cadastro") {
        if (!nome.trim()) throw new Error("Informe seu nome.");
        if (senha.length < 6) throw new Error("A senha precisa ter pelo menos 6 caracteres.");
        if (tipo === "vendedor") { const erro = validarVendedor(vend); if (erro) throw new Error(erro); }
        const { data, error } = await supabase.auth.signUp({
          email, password: senha,
          options: {
            emailRedirectTo: window.location.origin,
            data: { nome: nome.trim(), tipo, ...(tipo === "vendedor" ? vend : {}) },
          },
        });
        if (error) throw new Error(error.message.includes("registered") ? "Já existe uma conta com esse e-mail." : error.message.includes("weak") ? "Essa senha é muito fácil de adivinhar. Escolha outra." : error.message);
        if (!data.session) setEnviado("Enviamos um link de confirmação para o seu e-mail. Clique nele para ativar sua conta.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error;
        setEnviado("Se existir uma conta com esse e-mail, você receberá um link para criar uma nova senha.");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Algo deu errado.");
    } finally {
      setCarregando(false);
    }
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) toast.error("Não foi possível entrar com o Google.");
  }

  const titulo = { entrar: "Entre na sua conta", cadastro: "Crie sua conta", esqueci: "Recuperar senha" }[modo];

  return (
    <div className="relative min-h-[calc(100vh-4rem)] overflow-hidden">
      <div className="absolute inset-0 bg-glow" />
      <div className="relative mx-auto flex max-w-lg flex-col px-4 py-12">
        <div className="rounded-3xl border border-border bg-card p-8 shadow-lift">
          <img src={logo} alt="" className="mx-auto h-16 w-auto" />
          <h1 className="mt-4 text-center text-3xl">{titulo}</h1>
          {modo === "esqueci" && <p className="mt-2 text-center text-sm text-muted-foreground">Informe seu e-mail e enviaremos um link para você criar uma nova senha.</p>}

          {modo !== "esqueci" && (
            <div className="mt-6 grid grid-cols-2 rounded-full bg-muted p-1 text-sm font-semibold">
              {(["entrar", "cadastro"] as const).map((m) => (
                <button key={m} onClick={() => ir(m)} className={cn("rounded-full py-2 transition-all duration-200", modo === m ? "bg-gradient-warm text-primary-foreground shadow-glow" : "text-muted-foreground hover:text-foreground")}>
                  {m === "entrar" ? "Entrar" : "Cadastrar"}
                </button>
              ))}
            </div>
          )}

          {enviado ? (
            <div className="mt-6 rounded-2xl bg-success/10 p-5 text-center text-sm">
              <p className="font-semibold text-success">Verifique seu e-mail</p>
              <p className="mt-1 text-muted-foreground">{enviado}</p>
              <Button variant="link" onClick={() => ir("entrar")}>Voltar para o login</Button>
            </div>
          ) : (
            <form onSubmit={submit} className="mt-6 space-y-4">
              {modo === "cadastro" && (
                <>
                  <div>
                    <Label>Quero usar o Empreende Tec para</Label>
                    <div className="mt-2 grid grid-cols-2 gap-3">
                      {([["comprador", "Comprar", ShoppingBag], ["vendedor", "Vender", Store]] as const).map(([t, l, Icon]) => (
                        <button type="button" key={t} onClick={() => setTipo(t)} className={cn(
                          "group flex flex-col items-center gap-2 rounded-2xl border p-4 text-sm font-semibold transition-all duration-200",
                          tipo === t
                            ? "-translate-y-px border-primary/60 bg-primary/10 text-primary-deep shadow-glow"
                            : "border-border bg-card text-muted-foreground shadow-soft hover:-translate-y-px hover:border-primary/45 hover:text-foreground hover:shadow-lift active:translate-y-0",
                        )}>
                          <span className={cn(
                            "flex size-11 items-center justify-center rounded-full transition-all duration-200",
                            tipo === t ? "bg-gradient-warm text-primary-foreground ring-1 ring-primary-foreground/30" : "bg-secondary text-primary-deep group-hover:bg-accent",
                          )}>
                            <Icon className="size-5" />
                          </span>
                          {l}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="nome">Nome completo</Label>
                    <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} required />
                  </div>
                </>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="email">E-mail</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
              </div>
              {modo !== "esqueci" && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="senha">Senha</Label>
                    {modo === "entrar" && <button type="button" onClick={() => ir("esqueci")} className="text-xs font-semibold text-primary-deep hover:underline">Esqueci minha senha</button>}
                  </div>
                  <Input id="senha" type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required minLength={6}
                    autoComplete={modo === "entrar" ? "current-password" : "new-password"} />
                </div>
              )}
              {modo === "cadastro" && tipo === "vendedor" && <SellerFields v={vend} onChange={setVend} />}
              <Button type="submit" className="w-full" size="lg" disabled={carregando}>
                {carregando ? "Aguarde…" : modo === "entrar" ? "Entrar" : modo === "cadastro" ? "Criar conta" : "Enviar link de recuperação"}
              </Button>
              {modo === "esqueci" && <Button type="button" variant="link" className="w-full" onClick={() => ir("entrar")}>Voltar para o login</Button>}
            </form>
          )}

          {modo !== "esqueci" && !enviado && (
            <>
              <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />ou<span className="h-px flex-1 bg-border" /></div>
              <button type="button" onClick={google}
                className="flex h-11 w-full items-center justify-center gap-2.5 rounded-full border border-google-border bg-google-bg px-3 text-sm font-semibold text-google-fg shadow-soft transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lift active:translate-y-0">
                <GoogleIcon /> Continuar com Google
              </button>
            </>
          )}
        </div>
        <p className="mt-6 text-center text-xs text-muted-foreground">
          Ao continuar você concorda em negociar com respeito. <Link to="/sobre" className="underline">Saiba mais</Link>
        </p>
      </div>
    </div>
  );
}
